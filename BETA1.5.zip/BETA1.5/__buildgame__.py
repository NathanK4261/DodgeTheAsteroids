# Installer
import os
import stat
import getpass

usrname = getpass.getuser()

build = f'python3 /Users/{usrname}/DodgeTheAsteroids/BETA1.5/space_game.py'

with open('/Users/{usrname}/Desktop/DodgeTheAsteroids.command', 'w') as build_file:
    build_file.truncate(0)
    build_file.write(build)
    build_file.exit()

os.chmod(build, stat.S_IXOTH)
    
