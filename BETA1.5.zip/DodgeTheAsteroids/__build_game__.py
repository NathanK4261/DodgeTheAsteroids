# Installer
import os
import shutil
import time
import getpass
import sys
import stat

# Begin file transfer and build
usrname = getpass.getuser()
build = f'python3 /Users/{usrname}/DodgeTheAsteroids/BETA1.5/space_game.py'
with open(f'/Users/{usrname}/Desktop/DodgeTheAsteroids.command', 'w') as build_file:
    build_file.truncate()
    build_file.write(build)
    build_file.close()

time.sleep(3)
os.chmod(f'/Users/{usrname}/Desktop/DodgeTheAsteroids.command', stat.S_IRWXU)
