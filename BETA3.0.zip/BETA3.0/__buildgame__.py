# Installer
import os
import stat
import getpass

usrname = getpass.getuser()

build = f'python3 /Users/{usrname}/DodgeTheAsteroids/BETA3.0/space_game.py'

build_file_path = f'/Users/{usrname}/Desktop/DodgeTheAsteroids.command'

with open(build_file_path, 'w') as build_file:
    build_file.truncate(0)
    build_file.write(build)
    build_file.close()
    
